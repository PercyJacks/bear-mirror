#!/usr/bin/env sh

# RUN: %{citnames} --help