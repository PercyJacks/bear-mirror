#!/usr/bin/env sh

# XFAIL: *
# RUN: %{citnames} --verbose --input /non/exists
