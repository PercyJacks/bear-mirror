#!/usr/bin/env sh

# XFAIL: *
# RUN: %{intercept}
