#!/usr/bin/env sh

# XFAIL: *
# RUN: %{bear}
