#!/usr/bin/env sh

# XFAIL: *
# RUN: %{bear} --verbose --output %t.json -- %{false}
