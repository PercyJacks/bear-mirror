#!/usr/bin/env sh

# RUN: %{bear} --verbose --output %t.json -- %{true}
