#!/usr/bin/env sh

# RUN: %{bear} --help